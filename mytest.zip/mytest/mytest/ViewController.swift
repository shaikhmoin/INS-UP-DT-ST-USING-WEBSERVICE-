//
//  ViewController.swift
//  mytest
//
//  Created by MACOS on 7/1/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
var finalarr = [Any]()
    var st1 = [String]()
    var st = [String:Any]()
    
    @IBOutlet var tbl: UITableView!
    @IBOutlet var txtid: UITextField!
    @IBOutlet var txtadd: UITextField!
    @IBOutlet var txtname: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let str = String("http://localhost/MoinTest1/select.php")
        
        let url = URL(string: str!)
        
        var request = URLRequest(url: url!)
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data1,res,err) in
            
           //let str1 = String(data: data1!, encoding: String.Encoding.utf8)
           // print(str1)
            
            DispatchQueue.main.sync {
                do
                {
                    let json = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any]
                    
                    for item in json
                    {
                        //var temp = [String]()
                        //temp.append(item["Name"] as! String)
                        //temp.append(item["Address"] as! String)
                        
                        self.finalarr.append(item)
                        self.tbl.reloadData()
                    }
                    print(self.finalarr)
                }
                catch
                {
                    
                }
            }
            
        })
        
        datatask.resume()

    
    }

    @IBAction func btnInsert(_ sender: Any) {
        
        let str = String("http://localhost/MoinTest1/insert.php")
        
        let param = String("Name=\(txtname.text!)&Address=\(txtadd.text!)")
        
        let len = param?.characters.count
        
        let dt = param?.data(using: String.Encoding.utf8)
        
        let url = URL(string: str!)
        
        var request = URLRequest(url: url!)
        
        request.addValue(String(describing: len), forHTTPHeaderField: "Content-Length")
        
        request.httpBody = dt
        request.httpMethod = "POST"
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data1,res,err) in
          
            let str1 = String(data: data1!, encoding: String.Encoding.utf8)
            print(str1)
            
        })
        
        datatask.resume()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return finalarr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        // Section wise
        //let dic = finalarr[indexPath.section] as! [String]
       // cell?.textLabel?.text = dic[indexPath.row]
        
        let dicfinal = finalarr[indexPath.row] as! [String:Any]
        cell?.textLabel?.text = dicfinal["Name"] as! String
        cell?.detailTextLabel?.text = dicfinal["Address"] as! String
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        st = finalarr[indexPath.row] as! [String:Any]
        
        //st1 = [st["ID"] as! Int]

        txtid.text = st["ID"] as! String
    
        txtname.text = st["Name"] as! String?
        txtadd.text = st["Address"] as! String
        
        
    }
    @IBAction func btnUpdate(_ sender: Any) {
        
        let str = String("http://localhost/MoinTest1/update.php")
        
        let param = String("ID=\(txtid.text!)&Name=\(txtname.text!)&Address=\(txtadd.text!)")
        
        // print(param!)
        let len = param?.characters.count
        
        let dt = param?.data(using: String.Encoding.utf8)
        
        let url = URL(string: str!)
        // print(url)
        var request = URLRequest(url: url!)
        
        request.addValue(String(describing: len), forHTTPHeaderField: "Content-Length")
        
        request.httpBody = dt
        request.httpMethod = "POST"
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data1,res,err) in
            
            
            let str1 = String(data: data1!, encoding: String.Encoding.utf8)
            print(str1)
            
            
            
        })
        
        datatask.resume()

    }

    @IBAction func btndelete(_ sender: Any) {
       
       let str = String("http://localhost/MoinTest1/deletewish.php")
    
        let param = String("ID=\(txtid.text!)")
       // print(param!)
        let len = param?.characters.count
        
        let dt = param?.data(using: String.Encoding.utf8)
        
        let url = URL(string: str!)
       // print(url)
        var request = URLRequest(url: url!)
        
        request.addValue(String(describing: len), forHTTPHeaderField: "Content-Length")
        
        request.httpBody = dt
        request.httpMethod = "POST"
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data1,res,err) in
            
           
                    let str1 = String(data: data1!, encoding: String.Encoding.utf8)
                    print(str1)
        
            
            
        })
        
        datatask.resume()

        
    }

}

