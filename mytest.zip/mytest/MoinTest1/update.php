<?php

    $con=new MySQLi("localhost","root","","demo");
    
    $id = $_POST["ID"];
    $name = $_POST["Name"];
    $add = $_POST["Address"];

    
    echo $qu="update tblemp set Name='$name', Address='$add' where ID='$id'";

    $con->query($qu);
    
    echo "success";
    
?>

