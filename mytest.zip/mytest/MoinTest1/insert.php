<?php
    $con=new mysqli("localhost","root","","demo");

    $emp_name = $_POST["Name"];
    $emp_add = $_POST["Address"];
    
    $query = "insert into tblemp(Name,Address)values('$emp_name','$emp_add')";
    
    $con -> query($query);
    echo "success";   
?>
