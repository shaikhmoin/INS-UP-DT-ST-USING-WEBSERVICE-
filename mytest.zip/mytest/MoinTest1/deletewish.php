<?php
    $con=new mysqli("localhost","root","","demo");
    
    
    $a = $_POST['ID'];
   // print($a);
    
   echo $qp="delete from tblemp where ID='$a'";
    
    $con -> query($qp);
    echo "success";
   
?>
